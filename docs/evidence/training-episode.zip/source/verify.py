"""Re-simulate an episode from its seed and initial weights and compare arrays."""

import argparse
import json
import tempfile
from pathlib import Path

import numpy as np

from .config import EPISODES
from .episode import save_json
from .evidence import file_hashes
from .experiment import Experiment
from .provenance import provenance


def verify(path: Path):
    config = json.loads((path / "config.json").read_text())
    with np.load(path / "initial_weights.npz", allow_pickle=False) as saved:
        weights = saved["weights"]
    if config.get("provenance") != provenance():
        raise ValueError("Dynamics, body assets, kernel or runtime versions differ from this checkpoint")
    with (
        tempfile.TemporaryDirectory(prefix="gangnamfly-verify-") as scratch,
        np.load(path / "telemetry.npz", allow_pickle=False) as expected,
    ):
        hashes = file_hashes(path)
        result = verify_with_data(path, config, weights, Path(scratch), expected)
        if hashes != file_hashes(path):
            raise ValueError("Episode files changed during verification")
        save_json(path / "verification.json", {**result, "files": hashes})
        return result


def verify_with_data(path, config, weights, scratch, expected):
    experiment = Experiment(scratch)
    if (
        config["graph_sha256"] != experiment.brain.graph_hash
        or config["mapping_sha256"] != experiment.mapping_hash
    ):
        raise ValueError("Graph or mapping differs from recorded episode")
    if config.get("objective"):
        from .captured_target import load_target
        from .objective import CapturedObjective

        target = load_target(experiment.environment)
        if target.fingerprint != config["objective"]["target_hash"]:
            raise ValueError("Captured target differs from recorded episode")
        experiment.objective = CapturedObjective(
            target, experiment.environment.qadr, config["objective"]["criterion"]
        )
    experiment.begin(
        config["mode"],
        config["seed"],
        config["duration"],
        initial_weights=weights,
        teaching=config["teaching"],
        jitter=config["initial_joint_jitter_radians"],
    )
    try:
        for i in range(len(expected["time"])):
            experiment.step()
            e = experiment.environment
            for name, value in [("qpos", e.data.qpos), ("qvel", e.data.qvel), ("ctrl", e.data.ctrl)]:
                np.testing.assert_array_equal(value, expected[name][i], err_msg=f"{name} differs at tick {i}")
            np.testing.assert_array_equal(
                experiment.last_counts[experiment.brain.mapping.motor_indices], expected["motor_counts"][i]
            )
            np.testing.assert_equal(experiment.score, expected["reward"][i])
        with np.load(path / "weights.npz", allow_pickle=False) as final:
            np.testing.assert_array_equal(
                experiment.brain.native.weight[experiment.brain.plasticity.edges], final["weights"]
            )
        result = {
            "passed": True,
            "ticks": len(expected["time"]),
            "episode": path.name,
            "comparison": "exact qpos/qvel/ctrl/motor spikes/reward/final weights",
        }
        print(json.dumps(result))
        return result
    finally:
        experiment.finish("verification")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("episode", help="Recorded episode directory or ID")
    args = parser.parse_args()
    path = Path(args.episode)
    if not path.is_dir():
        path = EPISODES / args.episode
    verify(path)


if __name__ == "__main__":
    main()
