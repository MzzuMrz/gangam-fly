"""Serial, unlimited trials with held-out frozen evaluations and atomic checkpoints."""

import json
import uuid

import numpy as np

from .episode import save_json, save_npz
from .objective import CRITERION


class TrainingSession:
    def __init__(self, root, signature, seed=64, eval_every=5):
        self.root, self.signature = root, signature
        self.check_paths()
        root.mkdir(parents=True, exist_ok=True)
        (root / "history").mkdir(exist_ok=True)
        self.saved_weights = None
        self.active = False
        self.state = {
            "session_id": uuid.uuid4().hex[:16],
            "phase": "baseline",
            "seed": seed,
            "eval_every": eval_every,
            "evaluation_index": 0,
            "attempt": 0,
            "completed_trials": 0,
            "simulated_seconds": 0.0,
            "interrupted_seconds": 0.0,
            "baseline": [],
            "evaluation": [],
            "baseline_score": None,
            "best_score": None,
            "history": [],
        }
        checkpoint = root / "checkpoint.npz"
        if checkpoint.exists():
            with np.load(checkpoint, allow_pickle=False) as z:
                if json.loads(str(z["signature"])) != signature:
                    raise ValueError(
                        "Training checkpoint provenance differs; keep it and use a new session directory"
                    )
                state = json.loads(str(z["state"]))
                self.validate_state(state)
                self.state = state
                self.saved_weights = z["weights"].copy()
                if self.saved_weights.ndim != 1 or not np.isfinite(self.saved_weights).all():
                    raise ValueError("Invalid checkpoint weights")
            self.repair_history()
        self.validate_state(self.state)

    def check_paths(self):
        paths = [self.root, self.root / "history"]
        for name in ("checkpoint.npz", "checkpoint.partial", "best_weights.npz", "best_weights.partial"):
            paths.append(self.root / name)
        if any(p.is_symlink() for p in paths):
            raise ValueError("Training checkpoint paths cannot be symbolic links")

    def validate_state(self, state):
        def number(value, minimum=0.0, maximum=float("inf")):
            return type(value) in (int, float) and np.isfinite(value) and minimum <= value <= maximum

        try:
            if not isinstance(state, dict) or set(state) != set(self.state):
                raise ValueError("schema")
            for key in ("seed", "eval_every", "evaluation_index", "attempt", "completed_trials"):
                if type(state[key]) is not int or state[key] < (1 if key == "eval_every" else 0):
                    raise ValueError(key)
            if not isinstance(state["session_id"], str) or len(state["session_id"]) != 16:
                raise ValueError("session id")
            for key in ("simulated_seconds", "interrupted_seconds"):
                if not number(state[key]):
                    raise ValueError(key)
            for key in ("baseline_score", "best_score"):
                if state[key] is not None and not number(state[key], 0, 1):
                    raise ValueError(key)
            for key, maximum in (("baseline", 2), ("evaluation", 2), ("history", 100)):
                rows = state[key]
                if not isinstance(rows, list) or len(rows) > maximum:
                    raise ValueError(key)
                for row in rows:
                    if (
                        not isinstance(row, dict)
                        or not number(row["score"], 0, 1)
                        or not number(row["seconds"], 0, 120)
                    ):
                        raise ValueError("trial values")
                    if not isinstance(row["id"], str) or not row["id"] or any(c in row["id"] for c in "/\\"):
                        raise ValueError("trial id")
                    if row["phase"] not in ("baseline", "train", "evaluate"):
                        raise ValueError("trial phase")
                    if any(type(row[k]) is not int or row[k] < 0 for k in ("seed", "attempt")):
                        raise ValueError("trial counters")
                    if "passed" in row and type(row["passed"]) is not bool:
                        raise ValueError("trial result")
            if len(state["history"]) != min(100, state["completed_trials"]):
                raise ValueError("history length")
            phase, index = state["phase"], state["evaluation_index"]
            if phase == "baseline":
                valid = (
                    index in (0, 1)
                    and len(state["baseline"]) == index
                    and state["baseline_score"] is None
                    and state["attempt"] == 0
                    and not state["evaluation"]
                )
            else:
                valid = (
                    len(state["baseline"]) == 2
                    and state["baseline_score"] is not None
                    and state["attempt"] >= 1
                )
                if phase == "train":
                    valid = valid and index == 0 and not state["evaluation"]
                elif phase in ("evaluate", "complete"):
                    valid = (
                        valid
                        and state["attempt"] % state["eval_every"] == 0
                        and len(state["evaluation"]) == index
                        and index in ((0, 1) if phase == "evaluate" else (2,))
                    )
                    if phase == "complete":
                        valid = (
                            valid
                            and all(r.get("passed") is True for r in state["evaluation"])
                            and np.mean([r["score"] for r in state["evaluation"]])
                            > state["baseline_score"] + 0.001
                        )
                else:
                    valid = False
            if not valid:
                raise ValueError("phase invariants")
        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            raise ValueError(f"Invalid training checkpoint: {exc}") from exc

    def repair_history(self):
        # The atomic checkpoint is authoritative. A crash after its rename is
        # repaired idempotently into a stable sequence-numbered journal record.
        if self.state["history"]:
            self.check_paths()
            path = self.root / "history" / f"{self.state['completed_trials']:012d}.json"
            if path.is_symlink() or path.with_suffix(".json.partial").is_symlink():
                raise ValueError("Training history cannot be symbolic links")
            save_json(path, self.state["history"][-1])

    @property
    def phase(self):
        return self.state["phase"]

    def start(self):
        self.active = self.phase != "complete"

    def trial(self):
        s = self.state
        if self.phase in ("baseline", "evaluate"):
            return "observe", s["seed"] + 2 * s["evaluation_index"]
        return "train", s["seed"] + 2 * s["attempt"] + 1

    def checkpoint(self, weights):
        self.check_paths()
        self.validate_state(self.state)
        save_npz(
            self.root / "checkpoint.npz",
            weights=weights,
            state=np.array(json.dumps(self.state)),
            signature=np.array(json.dumps(self.signature)),
        )

    def stop(self, weights, seconds=0.0):
        self.state["interrupted_seconds"] += seconds
        self.active = False
        self.checkpoint(weights)

    def complete(self, summary, weights):
        s = self.state
        row = {**summary, "phase": self.phase, "attempt": s["attempt"], "seed": self.trial()[1]}
        s["history"] = (s["history"] + [row])[-100:]
        s["completed_trials"] += 1
        s["simulated_seconds"] += summary["seconds"]
        if self.phase in ("baseline", "evaluate"):
            key = "baseline" if self.phase == "baseline" else "evaluation"
            s[key].append(row)
            s["evaluation_index"] += 1
            if s["evaluation_index"] == 2:
                score = float(np.mean([r["score"] for r in s[key]]))
                if key == "baseline":
                    s["baseline_score"] = score
                else:
                    if s["best_score"] is None or score > s["best_score"]:
                        s["best_score"] = score
                        save_npz(
                            self.root / "best_weights.npz",
                            weights=weights,
                            score=np.array(score),
                            signature=np.array(json.dumps(self.signature)),
                        )
                    if all(r.get("passed", False) for r in s[key]) and score > s["baseline_score"] + 0.001:
                        s["phase"], self.active = "complete", False
                        self.checkpoint(weights)
                        self.repair_history()
                        return
                    s["evaluation"] = []
                s["evaluation_index"] = 0
                s["phase"] = "train"
                s["attempt"] += 1
        else:
            if s["attempt"] % s["eval_every"] == 0:
                s["phase"] = "evaluate"
                s["evaluation_index"] = 0
            else:
                s["attempt"] += 1
        self.checkpoint(weights)
        self.repair_history()

    def snapshot(self):
        return {
            **self.state,
            "active": self.active,
            "phase": self.phase if self.active or self.phase == "complete" else "stopped",
            "criterion": CRITERION,
        }
